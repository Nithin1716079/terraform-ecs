<img src="https://camo.githubusercontent.com/b313d4ec52b77b5024e2988aaf76720258233e69/68747470733a2f2f6f6662697a2e6170616368652e6f72672f696d616765732f6f6662697a5f6c6f676f2e706e67" alt="Apache OFBiz" />

# commonext component
This component enables organisations to extend the elements of the framework common component.

As the common component in the framework stack is under the control of the project, the need arose to enable adopters to extend the various elements (widgets, labels, etc) that component incorporates. For that purpose the commonext component was created in the application stack.

